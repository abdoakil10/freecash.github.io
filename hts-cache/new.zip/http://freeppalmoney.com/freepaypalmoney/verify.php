<html>

<head>

<meta http-equiv="refresh" content="0; url=http://freeppalmoney.com/getmoney.htm" />

</head>



</html>